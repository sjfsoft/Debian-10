#!/usr/bin/python
# -*- coding: utf-8 -*-

def version():
    return '3.4.0 2017-07-27'

